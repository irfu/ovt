/* 
* Header file for tsyg2001.f
*/

#ifndef _TSYG2001_H
#define _TSYG2001_H

extern int  t01_01_(int *, float *, float *, float *, 
	float *, float *, float *, float *, float *);	 
	
#endif	/* _TSYG2001_H */
