#ifndef _F2C_H
#define _F2C_H

/* This is not oryginal "f2c.h" file.  This one is made only
 * for application CGMC.
 */

#include <math.h>
typedef int integer;
typedef float real;
typedef double doublereal;
typedef int logical;
#define MAIN__ main
#define dabs(x) ((x)<0?-(x):(x))

#endif
