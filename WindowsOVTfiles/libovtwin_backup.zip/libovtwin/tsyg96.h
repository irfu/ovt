/* 
* Header file for tsyg96.f
*/

#ifndef _TSYG96_H
#define _TSYG96_H

extern int  t96_01_(int *, float *, float *, float *, 
	float *, float *, float *, float *, float *);	 
	
#endif	/* _TSYG96_H */
